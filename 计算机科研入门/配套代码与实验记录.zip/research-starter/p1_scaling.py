"""Controlled synthetic logistic-regression experiment; NumPy only."""
import argparse
import numpy as np
from common import prepare, save


def sigmoid(x):
    return 1 / (1 + np.exp(-np.clip(x, -60, 60)))


def loss(x, y, w):
    z = x @ w
    return float(np.mean(np.logaddexp(0, z) - y * z))


def dataset(seed):
    rng = np.random.default_rng(seed)
    z = rng.normal(size=(2000, 12))
    beta = np.array([2, -2, 1.5, -1.5, 1, -1] + [0] * 6)
    y = (rng.random(2000) < sigmoid(z @ beta)).astype(float)
    x = z * np.geomspace(0.1, 100, 12)
    ids = rng.permutation(len(y))
    return x, y, [ids[:1200], ids[1200:1600], ids[1600:]]


def design(x, train_ids, scale):
    mu = x[train_ids].mean(0) if scale else np.zeros(x.shape[1])
    sd = x[train_ids].std(0) if scale else np.ones(x.shape[1])
    sd = np.maximum(sd, 1e-8)
    return np.c_[(x - mu) / sd, np.ones(len(x))], mu, sd


def fit(x, y, lr, steps):
    w = np.zeros(x.shape[1])
    history = []
    for step in range(steps):
        w -= lr * (x.T @ (sigmoid(x @ w) - y)) / len(y)
        if step % 10 == 0 or step == steps - 1:
            history.append([step + 1, loss(x, y, w)])
    return w, history


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seeds', type=int, nargs='+', default=list(range(5)))
    p.add_argument('--steps', type=int, default=400)
    p.add_argument('--lrs', type=float, nargs='+', default=[0.0001, 0.001, 0.01, 0.1])
    p.add_argument('--finalize', action='store_true', help='Unlock test evaluation after protocol freeze')
    p.add_argument('--out')
    a = p.parse_args()
    if a.steps < 1 or not a.seeds or min(a.lrs) <= 0:
        p.error('positive steps/lrs and at least one seed required')
    out, meta = prepare(a, 'p1')
    records = []
    for seed in a.seeds:
        x, y, ids = dataset(seed)
        tr, va, te = ids
        np.savez(out / f'split-{seed}.npz', train=tr, val=va, test=te)
        for scale in [False, True]:
            group = 'standardized' if scale else 'raw'
            xx, mu, sd = design(x, tr, scale)
            candidates = []
            for lr in a.lrs:
                w, history = fit(xx[tr], y[tr], lr, a.steps)
                candidates.append((loss(xx[va], y[va], w), lr, w, history))
            val_loss, lr, w, history = min(candidates, key=lambda item: (item[0], item[1]))
            r = dict(seed=seed, group=group, lr=lr, val_loss=val_loss,
                     val_acc=float(np.mean((xx[va] @ w >= 0) == y[va])),
                     candidates=[dict(lr=c[1], val_loss=c[0]) for c in candidates], train_curve=history)
            if a.finalize:
                pred = (xx[te] @ w >= 0).astype(int)
                r.update(test_acc=float(np.mean(pred == y[te])), test_loss=loss(xx[te], y[te], w), n_test=len(te))
                r['confusion'] = [[int(np.sum((y[te] == i) & (pred == j))) for j in range(2)] for i in range(2)]
                np.savez(out / f'pred-{group}-{seed}.npz', ids=te, y=y[te], pred=pred)
            np.savez(out / f'model-{group}-{seed}.npz', w=w, mean=mu, std=sd)
            records.append(r)
            print(seed, group, 'val_loss=', round(val_loss, 4), 'lr=', lr)
    save(out, meta, records)


if __name__ == '__main__':
    main()
