"""Q-learning vs SARSA in classic 4x12 cliff walking (reset on fall)."""
import argparse
import csv
import numpy as np
from common import prepare, save

START, GOAL = 36, 47
MOVES = [(-1, 0), (0, 1), (1, 0), (0, -1)]


def transition(s, a):
    row, col = divmod(s, 12)
    dr, dc = MOVES[a]
    row, col = np.clip(row + dr, 0, 3), np.clip(col + dc, 0, 11)
    nxt = int(row * 12 + col)
    if row == 3 and 1 <= col <= 10:
        return START, -100.0, False, 1
    return nxt, -1.0, nxt == GOAL, 0


def action(q, s, eps, rng):
    if rng.random() < eps:
        return int(rng.integers(4))
    # Random tie breaking avoids a fixed action-index preference.
    return int(rng.choice(np.flatnonzero(q[s] == q[s].max())))


def run_episode(q, algo, eps, alpha, gamma, rng, max_steps, learn):
    s = START
    a = action(q, s, eps, rng)
    ret, falls = 0.0, 0
    for step in range(1, max_steps + 1):
        nxt, reward, terminated, fall = transition(s, a)
        ret += reward
        falls += fall
        nxt_a = None if terminated else action(q, nxt, eps, rng)
        if learn:
            bootstrap = 0.0 if terminated else (q[nxt].max() if algo == 'qlearning' else q[nxt, nxt_a])
            q[s, a] += alpha * (reward + gamma * bootstrap - q[s, a])
        if terminated:
            return ret, falls, step, True
        s, a = nxt, nxt_a
    # The cap is a truncation: the last learning update still bootstraps.
    return ret, falls, max_steps, False


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seeds', type=int, nargs='+', default=list(range(10)))
    p.add_argument('--episodes', type=int, default=500)
    p.add_argument('--eval-episodes', type=int, default=100)
    p.add_argument('--epsilon', type=float, default=0.1)
    p.add_argument('--alpha', type=float, default=0.5)
    p.add_argument('--gamma', type=float, default=1.0)
    p.add_argument('--max-steps', type=int, default=1000)
    p.add_argument('--out')
    a = p.parse_args()
    if min(a.episodes, a.eval_episodes, a.max_steps) < 1 or not 0 <= a.epsilon <= 1 or not 0 < a.alpha <= 1 or not 0 <= a.gamma <= 1:
        p.error('invalid count or learning parameter')
    out, meta = prepare(a, 'p3')
    records, curves = [], []
    for seed in a.seeds:
        for algo in ['qlearning', 'sarsa']:
            rng = np.random.default_rng(seed)
            q = np.zeros((48, 4))
            train = []
            for ep in range(a.episodes):
                values = run_episode(q, algo, a.epsilon, a.alpha, a.gamma, rng, a.max_steps, True)
                train.append(values)
                curves.append([seed, algo, ep + 1, *values])
            tail = train[-min(100, a.episodes):]
            rec = dict(seed=seed, group=algo, train_tail_return=float(np.mean([v[0] for v in tail])),
                       train_tail_falls=float(np.mean([v[1] for v in tail])),
                       train_steps=int(sum(v[2] for v in train)), train_success=float(np.mean([v[3] for v in train])))
            for name, eps in [('greedy', 0.0), ('explore', a.epsilon)]:
                eval_rng = np.random.default_rng(seed + 100000)
                values = [run_episode(q, algo, eps, a.alpha, a.gamma, eval_rng, a.max_steps, False) for _ in range(a.eval_episodes)]
                rec.update({name + '_return': float(np.mean([v[0] for v in values])),
                            name + '_falls': float(np.mean([v[1] for v in values])),
                            name + '_success': float(np.mean([v[3] for v in values]))})
            np.save(out / f'q-{algo}-{seed}.npy', q)
            records.append(rec)
            print(seed, algo, 'online=', round(rec['train_tail_return'], 2), 'greedy=', round(rec['greedy_return'], 2))
    with (out / 'curves.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['seed', 'algorithm', 'episode', 'return', 'falls', 'steps', 'success'])
        writer.writerows(curves)
    save(out, meta, records)


if __name__ == '__main__':
    main()
