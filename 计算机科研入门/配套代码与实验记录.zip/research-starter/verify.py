"""Scientific correctness checks. Add --torch after installing PyTorch."""
import argparse
import numpy as np
from p1_scaling import dataset, design, loss, sigmoid
from p3_cliff import transition, run_episode, START, GOAL


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--torch', action='store_true')
    args = p.parse_args()
    x, y, (tr, va, te) = dataset(0)
    assert len(set(tr) & set(va)) == len(set(tr) & set(te)) == len(set(va) & set(te)) == 0
    assert len(set(np.r_[tr, va, te])) == len(y)
    xx, mu, sd = design(x, tr, True)
    assert np.allclose(xx[tr, :-1].mean(0), 0, atol=1e-12)
    changed = x.copy()
    changed[te] += 10000
    _, other_mu, other_sd = design(changed, tr, True)
    assert np.array_equal(mu, other_mu) and np.array_equal(sd, other_sd)
    small_x, small_y = xx[:20], y[:20]
    w = np.random.default_rng(0).normal(size=xx.shape[1]) * .1
    analytic = small_x.T @ (sigmoid(small_x @ w) - small_y) / len(small_y)
    numeric = []
    for j in range(len(w)):
        delta = np.zeros_like(w)
        delta[j] = 1e-5
        numeric.append((loss(small_x, small_y, w + delta) - loss(small_x, small_y, w - delta)) / 2e-5)
    assert np.allclose(analytic, numeric, atol=1e-8)
    assert transition(START, 1) == (START, -100, False, 1)
    assert transition(START, 3) == (START, -1, False, 0)
    assert transition(35, 2) == (GOAL, -1, True, 0)
    q = np.full((48, 4), -10.0)
    q[START, 0] = 1
    q[24:35, 1] = 1
    q[35, 2] = 1
    q[GOAL] = 999
    snapshot = q.copy()
    result = run_episode(q, 'qlearning', 0, 1, 1, np.random.default_rng(0), 100, False)
    assert result == (-13, 0, 13, True)
    assert np.array_equal(q, snapshot), 'Evaluation modified Q'
    run_episode(q, 'qlearning', 0, 1, 1, np.random.default_rng(0), 100, True)
    assert q[35, 2] == -1, 'Terminal update must ignore terminal-state Q'
    if args.torch:
        import torch
        from p2_fashion import model_for, evaluate
        torch.set_num_threads(2)
        for arm, expected in [('mlp', 101770), ('cnn', 105866), ('cnn_noise', 105866)]:
            model = model_for(arm)
            assert model(torch.zeros(2, 1, 28, 28)).shape == (2, 10)
            assert sum(p.numel() for p in model.parameters()) == expected
            before = {k: v.detach().clone() for k, v in model.state_dict().items()}
            evaluate(model, torch.zeros(2, 1, 28, 28), torch.tensor([0, 1]), torch.device('cpu'), .15, 2, 0)
            assert all(torch.equal(before[k], v) for k, v in model.state_dict().items())
    print('PASS: split isolation, preprocessing isolation, finite-difference gradient, cliff rules, terminal target, frozen evaluation' + (', model shapes/parameters' if args.torch else ''))


if __name__ == '__main__':
    main()
