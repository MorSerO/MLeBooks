"""Shared experiment bookkeeping. No network calls at import time."""
import datetime as dt
import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path
import numpy as np


def prepare(args, project):
    out = Path(args.out or ('runs/' + project + '-' + dt.datetime.now().strftime('%Y%m%d-%H%M%S-%f')))
    out.mkdir(parents=True, exist_ok=False)
    config = vars(args).copy()
    try:
        commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], stderr=subprocess.DEVNULL, text=True).strip()
        dirty = bool(subprocess.check_output(['git', 'status', '--porcelain'], stderr=subprocess.DEVNULL, text=True).strip())
    except (OSError, subprocess.CalledProcessError):
        commit, dirty = 'unavailable', None
    meta = dict(project=project, config=config, time=dt.datetime.now(dt.timezone.utc).isoformat(),
                python=sys.version, numpy=np.__version__, platform=platform.platform(),
                processor=platform.processor(), logical_cpus=os.cpu_count(),
                git_commit=commit, git_dirty=dirty,
                source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob('*.py'))},
                config_sha256=hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest())
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    return out, meta


def save(out, meta, records):
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    (out / 'results.json').write_text(json.dumps(dict(metadata=meta, records=records), indent=2, allow_nan=False), encoding='utf-8')
    print('Saved:', out.resolve())
