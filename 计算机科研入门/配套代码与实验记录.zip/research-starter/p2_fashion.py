"""Fashion-MNIST: MLP / CNN / CNN with Gaussian training noise.
No torchvision dependency. The official IDX files are read directly.
"""
import argparse
import copy
import gzip
import hashlib
import json
import random
import struct
import time
import urllib.request
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from common import prepare, save

FILES = {
    'train-images-idx3-ubyte.gz': '8d4fb7e6c68d591d4c3dfef9ec88bf0d',
    'train-labels-idx1-ubyte.gz': '25c81989df183df01b3e8a0aad5dffbe',
    't10k-images-idx3-ubyte.gz': 'bef4ecab320f06d8554ea6380940ec79',
    't10k-labels-idx1-ubyte.gz': 'bb300cfdad3c16e7a12a480ee83cd310',
}
BASE = 'https://raw.githubusercontent.com/zalandoresearch/fashion-mnist/master/data/fashion/'


def read_idx(root, name, download):
    root.mkdir(parents=True, exist_ok=True)
    path = root / name
    if not path.exists():
        if not download:
            raise FileNotFoundError(f'{path}: use --download or obtain official files')
        temp = path.with_suffix('.part')
        urllib.request.urlretrieve(BASE + name, temp)
        if hashlib.md5(temp.read_bytes()).hexdigest() != FILES[name]:
            temp.unlink()
            raise ValueError('Download checksum mismatch: ' + name)
        temp.replace(path)
    if hashlib.md5(path.read_bytes()).hexdigest() != FILES[name]:
        raise ValueError('Dataset checksum mismatch: ' + name)
    data = gzip.decompress(path.read_bytes())
    magic, count = struct.unpack('>II', data[:8])
    if magic == 2051:
        rows, cols = struct.unpack('>II', data[8:16])
        return np.frombuffer(data, dtype=np.uint8, offset=16).copy().reshape(count, 1, rows, cols)
    if magic == 2049:
        return np.frombuffer(data, dtype=np.uint8, offset=8).copy().reshape(count)
    raise ValueError('Not a supported IDX file')


def model_for(arm):
    if arm == 'mlp':
        return nn.Sequential(nn.Flatten(), nn.Linear(784, 128), nn.ReLU(), nn.Linear(128, 10))
    return nn.Sequential(nn.Conv2d(1, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                         nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                         nn.Flatten(), nn.Linear(32 * 7 * 7, 64), nn.ReLU(), nn.Linear(64, 10))


def evaluate(model, x, y, device, noise, batch, noise_seed):
    model.eval()
    gen = torch.Generator().manual_seed(noise_seed)
    pred, total_loss = [], 0.0
    with torch.no_grad():
        for start in range(0, len(y), batch):
            xx = x[start:start + batch]
            if noise:
                xx = (xx + noise * torch.randn(xx.shape, generator=gen)).clamp(0, 1)
            yy = y[start:start + batch].to(device)
            logits = model(xx.to(device))
            total_loss += nn.functional.cross_entropy(logits, yy, reduction='sum').item()
            pred.append(logits.argmax(1).cpu())
    predictions = torch.cat(pred)
    return float((predictions == y).float().mean()), total_loss / len(y), predictions.numpy()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seeds', type=int, nargs='+', default=list(range(5)))
    p.add_argument('--arms', nargs='+', choices=['mlp', 'cnn', 'cnn_noise'], default=['mlp', 'cnn', 'cnn_noise'])
    p.add_argument('--epochs', type=int, default=5)
    p.add_argument('--train-size', type=int, default=12000)
    p.add_argument('--val-size', type=int, default=3000)
    p.add_argument('--batch-size', type=int, default=128)
    p.add_argument('--lr', type=float, default=0.001)
    p.add_argument('--train-noise', type=float, default=0.15)
    p.add_argument('--test-noises', type=float, nargs='+', default=[0, 0.15, 0.3])
    p.add_argument('--device', default='cpu')
    p.add_argument('--threads', type=int, default=2)
    p.add_argument('--data', default='data/fashion')
    p.add_argument('--download', action='store_true')
    p.add_argument('--finalize', action='store_true')
    p.add_argument('--smoke', action='store_true', help='Random tensors; no real-dataset conclusions')
    p.add_argument('--out')
    a = p.parse_args()
    if min(a.epochs, a.train_size, a.val_size, a.batch_size, a.threads) < 1 or a.train_size + a.val_size > 60000 or a.lr <= 0 or min(a.test_noises) < 0 or a.train_noise < 0:
        p.error('invalid sizes/rates/noises')
    torch.set_num_threads(a.threads)
    out, meta = prepare(a, 'p2')
    device = torch.device(a.device)
    meta.update(torch=torch.__version__, device=str(device), cuda=torch.version.cuda,
                dataset='random_smoke' if a.smoke else 'Fashion-MNIST', split_seed=2026)
    if a.smoke:
        g = torch.Generator().manual_seed(2026)
        xall, yall = torch.rand(128, 1, 28, 28, generator=g), torch.randint(10, (128,), generator=g)
        xtr, ytr, xva, yva, xte, yte = xall[:96], yall[:96], xall[96:], yall[96:], xall[96:], yall[96:]
        meta['warning'] = 'Random fixture; validation reused as smoke test. Not scientific evidence.'
    else:
        root = Path(a.data)
        xall = torch.from_numpy(read_idx(root, 'train-images-idx3-ubyte.gz', a.download)).float() / 255
        yall = torch.from_numpy(read_idx(root, 'train-labels-idx1-ubyte.gz', a.download)).long()
        ids = np.random.default_rng(2026).permutation(len(yall))
        tr, va = ids[:a.train_size], ids[a.train_size:a.train_size + a.val_size]
        np.savez(out / 'split.npz', train=tr, val=va)
        xtr, ytr, xva, yva = xall[tr], yall[tr], xall[va], yall[va]
        if a.finalize:
            xte = torch.from_numpy(read_idx(root, 't10k-images-idx3-ubyte.gz', a.download)).float() / 255
            yte = torch.from_numpy(read_idx(root, 't10k-labels-idx1-ubyte.gz', a.download)).long()
        meta['dataset_md5'] = FILES
    records, curves = [], []
    for seed in a.seeds:
        for arm in a.arms:
            random.seed(seed)
            np.random.seed(seed)
            torch.manual_seed(seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(seed)
            torch.backends.cudnn.benchmark = False
            torch.use_deterministic_algorithms(True)
            loader = DataLoader(TensorDataset(xtr, ytr), batch_size=a.batch_size, shuffle=True,
                                generator=torch.Generator().manual_seed(seed), num_workers=0)
            aug_gen = torch.Generator().manual_seed(seed + 20000)
            model = model_for(arm).to(device)
            opt = torch.optim.Adam(model.parameters(), lr=a.lr)
            best_loss, best_state, best_epoch = float('inf'), None, None
            if device.type == 'cuda':
                torch.cuda.synchronize()
            start = time.perf_counter()
            for epoch in range(a.epochs):
                model.train()
                total = 0.0
                for xx, yy in loader:
                    if arm == 'cnn_noise':
                        xx = (xx + a.train_noise * torch.randn(xx.shape, generator=aug_gen)).clamp(0, 1)
                    xx, yy = xx.to(device), yy.to(device)
                    opt.zero_grad(set_to_none=True)
                    loss = nn.functional.cross_entropy(model(xx), yy)
                    loss.backward()
                    opt.step()
                    total += loss.item() * len(yy)
                acc, vl, _ = evaluate(model, xva, yva, device, 0, a.batch_size, 999)
                curves.append(dict(seed=seed, arm=arm, epoch=epoch + 1, train_loss=total / len(ytr), val_loss=vl, val_acc=acc))
                if vl < best_loss:
                    best_loss, best_epoch = vl, epoch + 1
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                print(seed, arm, epoch + 1, round(total / len(ytr), 4), round(acc, 4), flush=True)
            if device.type == 'cuda':
                torch.cuda.synchronize()
            elapsed = time.perf_counter() - start
            model.load_state_dict(best_state)
            torch.save(dict(state_dict=best_state, arm=arm, seed=seed, best_epoch=best_epoch), out / f'{arm}-{seed}.pt')
            acc, vl, _ = evaluate(model, xva, yva, device, 0, a.batch_size, 999)
            rec = dict(seed=seed, group=arm, val_loss=vl, val_acc=acc, best_epoch=best_epoch,
                       seconds=elapsed, parameters=sum(v.numel() for v in model.parameters()), n_train=len(ytr), n_val=len(yva))
            if a.finalize or a.smoke:
                rec['n_test'] = len(yte)
                for noise in a.test_noises:
                    acc, tl, pred = evaluate(model, xte, yte, device, noise, a.batch_size, seed + 30000)
                    rec[f'test_acc_noise_{noise:g}'] = acc
                    rec[f'test_loss_noise_{noise:g}'] = tl
                    np.savez(out / f'pred-{arm}-{seed}-noise-{noise:g}.npz', y=yte.numpy(), pred=pred)
            records.append(rec)
    (out / 'curves.json').write_text(json.dumps(curves, indent=2), encoding='utf-8')
    save(out, meta, records)


if __name__ == '__main__':
    main()
