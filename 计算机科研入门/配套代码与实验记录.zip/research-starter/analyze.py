"""Summarize seed-level metrics and optional paired bootstrap difference."""
import argparse
import json
from collections import defaultdict
from pathlib import Path
import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('results')
    p.add_argument('--metric', required=True)
    p.add_argument('--pair', nargs=2, metavar=('A', 'B'))
    a = p.parse_args()
    data = json.loads(Path(a.results).read_text(encoding='utf-8'))
    groups = defaultdict(dict)
    for r in data['records']:
        if a.metric not in r:
            p.error('Metric not present: ' + a.metric)
        if r['seed'] in groups[r['group']]:
            p.error('Duplicate seed within group')
        groups[r['group']][r['seed']] = float(r[a.metric])
    result = dict(metric=a.metric, groups={})
    for group, rows in groups.items():
        x = np.array(list(rows.values()))
        result['groups'][group] = dict(n=len(x), mean=float(x.mean()),
                                      sample_std=float(x.std(ddof=1)) if len(x) > 1 else None, values=rows)
    if a.pair:
        ga, gb = a.pair
        if ga not in groups or gb not in groups or set(groups[ga]) != set(groups[gb]):
            p.error('Paired groups must contain exactly the same seed IDs')
        ids = sorted(groups[ga])
        d = np.array([groups[ga][s] - groups[gb][s] for s in ids])
        ci = None
        if len(d) >= 2:
            means = np.random.default_rng(2026).choice(d, size=(10000, len(d)), replace=True).mean(1)
            ci = np.quantile(means, [0.025, 0.975]).tolist()
        result['paired'] = dict(direction=ga + ' minus ' + gb, n=len(d), mean_difference=float(d.mean()),
                                bootstrap_percentile_95=ci, differences=d.tolist(),
                                caveat='Seed-level interval, conditional on this protocol; small n is unstable.')
    target = Path(a.results).with_name('summary-' + a.metric.replace('.', '_') + '.json')
    target.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
