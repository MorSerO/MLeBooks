# 《计算机科研入门》配套实验

面向计算机科研入门的三个逐步进阶项目。先阅读教材对应的协议与解释。

## 环境

推荐 Python 3.12。项目一/三依赖 NumPy；项目二另外依赖 PyTorch，不需要 torchvision。

Windows PowerShell：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-core.txt
.\.venv\Scripts\python.exe verify.py
```

后续 `python` 均替换为当前环境解释器；Linux 使用 `.venv/bin/python`。CPU 深度学习安装：

```powershell
.\.venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe verify.py --torch
.\.venv\Scripts\python.exe -m pip freeze > requirements-lock.txt
```

GPU 安装见 [PyTorch 官方选择器](https://pytorch.org/get-started/locally/)。兼容范围文件便于起步；本次精确核心版本记录在 VALIDATION.md 中。

## 项目一

```bash
python p1_scaling.py --seeds 0 --steps 40 --out runs/p1-check
python p1_scaling.py --finalize --out runs/p1-main
python analyze.py runs/p1-main/results.json --metric test_acc --pair standardized raw
```

没有 `--finalize` 时不评估测试集。正式评估前冻结协议。

## 项目二

```bash
python p2_fashion.py --smoke --seeds 0 --epochs 1 --out runs/p2-smoke
python p2_fashion.py --download --seeds 0 --epochs 2 --out runs/p2-dev
python p2_fashion.py --download --finalize --out runs/p2-main
python analyze.py runs/p2-main/results.json --metric test_acc_noise_0.3 --pair cnn_noise cnn
```

`--smoke` 使用随机张量，仅验证贯通，不能作为科学结果。真实数据从 [官方仓库](https://github.com/zalandoresearch/fashion-mnist) 下载；核对 MD5。数据许可见官方 LICENSE；压缩包不再分发数据本身。CPU 默认两线程，GPU 可加 `--device cuda`。

## 项目三

```bash
python p3_cliff.py --seeds 0 --episodes 20 --eval-episodes 10 --out runs/p3-check
python p3_cliff.py --out runs/p3-main
python analyze.py runs/p3-main/results.json --metric train_tail_return --pair sarsa qlearning
python analyze.py runs/p3-main/results.json --metric greedy_return --pair sarsa qlearning
```

环境为 4×12 经典悬崖，跌落重置但不终止；时间上限是截断，最后更新仍 bootstrap。训练比较固定回合数，实际转移数同时记录。参考结果保留了 SARSA 的两个失败种子。

## 输出与复现

输出目录已存在时程序会失败，避免覆盖；修改 `--out` 后重试。省略 `--out` 自动创建带时间的目录。

- `metadata.json`：配置、环境、时间、代码 SHA-256、Git 状态。
- `results.json`：逐种子结果、选择配置；P1 还有候选损失。
- `split*.npz`：数据划分；`pred*.npz`：最终预测。
- 模型文件：P1 `.npz`、P2 `.pt`、P3 `.npy`。
- P2 `curves.json`；P3 `curves.csv`：训练过程。

`reference_runs/` 是本书真实主实验记录，不含 P1/P2 模型检查点，不含 Fashion-MNIST 原始图像。保存了预测、划分、曲线和 P3 Q 表，便于审计数字。重绘书中结果图需安装 `matplotlib`：

```bash
python -m pip install matplotlib
python make_figures.py --runs reference_runs --out figures
```

图例中的 SD 为跨训练种子的样本标准差。命令依赖所在目录，请先进入解压后的代码包根目录。

## 教学与研究边界

这些项目是教学复现和小型测量，不代表已具备投稿创新性。最终测试集若已反复观察，继续修改方案必须标为探索。所有数字应从实际记录获得；空白模板不应填猜测值。

`worked_reports/` 提供三篇精简的完成态教学报告，包含真实数字、方法、结果、局限与引用，帮助理解如何把实验变成论文。它们不是已发表成果，不能未经独立研究就作为自己的原创论文提交。
