"""Replot the textbook's measured results from saved run records."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

BLUE, TEAL, ORANGE = '#244A73', '#087F8C', '#DC7941'


def setup(font=None):
    if font:
        font_manager.fontManager.addfont(font)
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font).get_name()
    else:
        plt.rcParams['font.family'] = ['Microsoft YaHei', 'Noto Sans CJK SC', 'DejaVu Sans']
    plt.rcParams.update({'font.size': 10.5, 'axes.titlesize': 11.5, 'axes.labelsize': 10.5,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.unicode_minus': False, 'grid.alpha': .18,
                         'savefig.dpi': 220, 'figure.facecolor': 'white'})


def read(runs, name):
    return json.loads((Path(runs) / name / 'results.json').read_text(encoding='utf-8'))['records']


def finish(fig, out, name):
    fig.savefig(Path(out) / (name + '.png'), bbox_inches='tight', pad_inches=.18)
    fig.savefig(Path(out) / (name + '.pdf'), bbox_inches='tight', pad_inches=.18)
    plt.close(fig)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--runs', default='reference_runs')
    p.add_argument('--out', default='figures')
    p.add_argument('--font')
    a = p.parse_args()
    Path(a.out).mkdir(parents=True, exist_ok=True)
    setup(a.font)
    rows = read(a.runs, 'p1-main')
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.5), layout='constrained')
    for seed in sorted({r['seed'] for r in rows}):
        values = [next(r['test_acc'] * 100 for r in rows if r['seed'] == seed and r['group'] == g) for g in ['raw', 'standardized']]
        axes[0].plot([0, 1], values, '-o', color=BLUE, alpha=.6, lw=1.1, markersize=4)
    axes[0].set(xticks=[0, 1], xticklabels=['原始输入', '标准化'], ylabel='测试准确率 / %', title='每条线连接同一个数据种子', ylim=(40, 100))
    for group, label, color in [('raw', '原始输入', BLUE), ('standardized', '标准化', TEAL)]:
        r = next(r for r in rows if r['seed'] == 0 and r['group'] == group)
        curve = np.array(r['train_curve'])
        axes[1].plot(curve[:, 0], curve[:, 1], label=label, color=color, lw=2)
    axes[1].set(xlabel='梯度更新次数', ylabel='训练交叉熵', title='种子 0；各自选中的学习率')
    axes[1].legend(frameon=False)
    for ax in axes:
        ax.grid(axis='y')
    finish(fig, a.out, 'p1_results')
    rows = read(a.runs, 'p2-main')
    fig, ax = plt.subplots(figsize=(7.2, 4.1), layout='constrained')
    noises = [0, .15, .3]
    for group, color, marker, label in [('mlp', BLUE, 'o', 'MLP'), ('cnn', ORANGE, 's', 'CNN'), ('cnn_noise', TEAL, '^', 'CNN + 训练噪声')]:
        values = np.array([[r[f'test_acc_noise_{n:g}'] * 100 for n in noises] for r in rows if r['group'] == group])
        ax.errorbar(noises, values.mean(0), yerr=values.std(0, ddof=1), color=color, marker=marker,
                    capsize=4, lw=2, markersize=6, label=label)
    ax.set(xlabel='测试高斯噪声标准差（像素范围 [0,1]）', ylabel='测试准确率 / %', xticks=noises,
           title='固定数据划分；5 个训练种子；误差条为跨种子样本 SD', ylim=(45, 95))
    ax.legend(frameon=False, loc='lower left')
    ax.grid(axis='y')
    finish(fig, a.out, 'p2_results')
    rows = read(a.runs, 'p3-main')
    with (Path(a.runs) / 'p3-main' / 'curves.csv').open(encoding='utf-8') as f:
        raw = list(csv.DictReader(f))
    fig = plt.figure(figsize=(7.2, 6.6), layout='constrained')
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1])
    top = fig.add_subplot(gs[0, :])
    for group, label, color in [('qlearning', 'Q-learning', BLUE), ('sarsa', 'SARSA', TEAL)]:
        data = np.array([[float(r['return']) for r in raw if r['algorithm'] == group and int(r['seed']) == s] for s in range(10)])
        blocked = data.reshape(10, 50, 10).mean(2)
        x = np.arange(10, 501, 10)
        mean, sd = blocked.mean(0), blocked.std(0, ddof=1)
        top.plot(x, mean, lw=1.6, color=color, label=label)
        top.fill_between(x, mean - sd, mean + sd, color=color, alpha=.12)
    top.set(xlabel='训练回合（每 10 回合分块平均）', ylabel='在线训练回报', title='均值与跨种子样本 SD；回报越高越好')
    top.legend(frameon=False)
    top.grid(axis='y')
    for col, metric, title in [(0, 'explore_return', '冻结后探索评估 / epsilon=0.1'), (1, 'greedy_return', '冻结后贪心评估 / epsilon=0')]:
        ax = fig.add_subplot(gs[1, col])
        for i, group in enumerate(['qlearning', 'sarsa']):
            values = [r[metric] for r in rows if r['group'] == group]
            ax.scatter(i + np.linspace(-.11, .11, len(values)), values, color=[BLUE, TEAL][i], s=22, alpha=.8)
            ax.plot([i-.18, i+.18], [np.mean(values)]*2, color='black', lw=1.6)
        ax.set(xticks=[0, 1], xticklabels=['Q-learning', 'SARSA'], ylabel='每种子的 100 回合平均回报', title=title)
        ax.grid(axis='y')
    finish(fig, a.out, 'p3_results')
    print('Wrote result figures to', Path(a.out).resolve())


if __name__ == '__main__':
    main()
